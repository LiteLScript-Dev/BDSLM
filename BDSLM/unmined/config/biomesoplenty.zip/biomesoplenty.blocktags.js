/**
 *
 * Block tags for BiomesOPlenty
 * ============================
 *
 *
 * This script assigns default tags to BiomesOPlenty blocks.
 * The default stylesheet uses these tags to determine block styles.
 *
 *
 * https://www.curseforge.com/minecraft/mc-mods/biomes-o-plenty
 *
 *
 */


var STYLESHEET = {
    name: "uNmINeD - BiomesOPlenty block tags",
    main: function (b) {
        addBiomesOPlenty(b);
    }
}

function addBiomesOPlenty(b) {
    b.tag("#leaves").apply("biomesoplenty:petals");

    
    b.tag("#flower, #white").apply("biomesoplenty:clover");
    b.tag("#flower, #yellow").apply("biomesoplenty:goldenrod, biomesoplenty:glowflower");
    b.tag("#flower, #pink").apply("biomesoplenty:pink_daffodil, biomesoplenty:pink_hibiscus");
    b.tag("#flower, #orange").apply("biomesoplenty:orange_cosmos, biomesoplenty:burning_blossom");
    b.tag("#flower, #light_blue").apply("biomesoplenty:blue_hydrangea");
    b.tag("#flower, #purple").apply("biomesoplenty:violet");
    b.tag("#flower, #magenta").apply("biomesoplenty:lavender, biomesoplenty:wildflower");
    b.tag("#flower, #brown").apply("biomesoplenty:wilted_lily, biomesoplenty:cattail");

    b.tag("#bush").apply("biomesoplenty:bush");

    b.tag("#mushroom").apply("biomesoplenty:toadstool, biomesoplenty:glowshroom");
    b.tag("#mushroom").apply("biomesoplenty:glowshroom_block");
    b.tag("#grass").apply("biomesoplenty:huge_clover_petal, biomesoplenty:sea_oats, biomesoplenty:reed");
    b.tag("#seagrass").apply("biomesoplenty:watergrass").waterlogged();
    b.tag("#vine").apply("biomesoplenty:willow_vine");

    b.tag("#log").apply("biomesoplenty:bramble");

    b.tag("#mud").apply("biomesoplenty:mud");
    b.tag("#rock").apply("biomesoplenty:crag_rock");

    b.tag("#sand,#terrain,#ground").apply(
        "biomesoplenty:white_sand",
        "biomesoplenty:black_sand",
        "biomesoplenty:orange_sand");

    b.tag("#wooden").apply(
        "biomesoplenty:cherry_* !#natural",
        "biomesoplenty:dead_* !#natural",
        "biomesoplenty:fir_* !#natural",
        "biomesoplenty:jacarandra_* !#natural",
        "biomesoplenty:mahogany_* !#natural",
        "biomesoplenty:hellbark_* !#natural",
        "biomesoplenty:palm_* !#natural",
        "biomesoplenty:redwood_* !#natural",
        "biomesoplenty:umbran_* !#natural",
        "biomesoplenty:willow_* !#natural",
        "biomesoplenty:stripped_*_log",
        "biomesoplenty:stripped_*_wood",
        ).artificial();

    b.tag("#magic").apply(
        "biomesoplenty:magic_* !#natural").artificial();

    b.tag("#stone").apply([
        "biomesoplenty:black_sandstone_* !#natural",
        "biomesoplenty:orange_sandstone_* !#natural",
        "biomesoplenty:white_sandstone_* !#natural",
        "biomesoplenty:smooth_black_sandstone_* !#natural",
        "biomesoplenty:smooth_orange_sandstone_* !#natural",
        "biomesoplenty:smooth_white_sandstone_* !#natural"
    ]).artificial();

    // Older versions

    b.tag("#vine").apply("BiomesOPlenty:treeMoss");
    b.tag("#grass").apply("BiomesOPlenty:longGrass");
    b.tag("#sand").apply("BiomesOPlenty:hardSand");
    b.tag("#dirt").apply("BiomesOPlenty:hardDirt");
}